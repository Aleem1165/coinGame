import logo from "./logo.svg";
import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Login from "./screens/Login";
import Signup from "./screens/Signup";
import Home from "./screens/Home";

function App() {
  return <Home />;
}

export default App;
