import React from "react";
import "./style.css";
import HomeHeader from "../../component/HomeHeader";
import SideBar from "../../component/sideBar";
import homeSwipe1 from "../../images/homeSwipe1.png";
import homeSwipe2 from "../../images/homeSwipe2.png";
import homeSwipe3 from "../../images/homeSwipe3.png";
import homeSwipRightArrow from "../../images/homeSwipRightArrow.png";
import homeSwipLeftArrow from "../../images/homeSwipLeftArrow.png";
import dailyBonus from "../../images/dailyBonus.png";
import freeBoxes from "../../images/freeBoxes.png";
import Promocodes from "../../images/Promocodes.png";
import Rakeback from "../../images/Rakeback.png";
import vipClub from "../../images/vipClub.png";
import sidebar2 from "../../images/sidebar2.png";
import game1 from "../../images/game1.png";
import game2 from "../../images/game2.png";
import game3 from "../../images/game3.png";
import game4 from "../../images/game4.png";
import game5 from "../../images/game5.png";
import game6 from "../../images/game6.png";
import game7 from "../../images/game7.png";
import game8 from "../../images/game8.png";
import game9 from "../../images/game9.png";
import game10 from "../../images/game10.png";
import game11 from "../../images/game11.png";
import game12 from "../../images/game12.png";
import game13 from "../../images/game13.png";
import game14 from "../../images/game14.png";
import game15 from "../../images/game15.png";
import game16 from "../../images/game16.png";
import game17 from "../../images/game17.png";
import game18 from "../../images/game18.png";
import game19 from "../../images/game19.png";
import game20 from "../../images/game20.png";
import game21 from "../../images/game21.png";
import game22 from "../../images/game22.png";
import game23 from "../../images/game23.png";
import game24 from "../../images/game24.png";
import game25 from "../../images/game25.png";
import game26 from "../../images/game26.png";
import game27 from "../../images/game27.png";
import game28 from "../../images/game28.png";
import game29 from "../../images/game29.png";
import game30 from "../../images/game30.png";
import game31 from "../../images/game31.png";
import game32 from "../../images/game32.png";
import game33 from "../../images/game33.png";
import game34 from "../../images/game34.png";
import game35 from "../../images/game35.png";
import paymentImg from "../../images/paymentImg.png";
import gameProvider1 from "../../images/gameProvider1.png";
import gameProvider2 from "../../images/gameProvider2.png";
import gameProvider3 from "../../images/gameProvider3.png";
import gameProvider4 from "../../images/gameProvider4.png";
import gameProvider5 from "../../images/gameProvider5.png";
import gameProvider6 from "../../images/gameProvider6.png";
import gameProvider7 from "../../images/gameProvider7.png";
import liveGame1 from "../../images/liveGame1.png";
import liveGame2 from "../../images/liveGame2.png";
import liveGame3 from "../../images/liveGame3.png";
import liveGame4 from "../../images/liveGame4.png";
import liveGame5 from "../../images/liveGame5.png";
import liveGame6 from "../../images/liveGame6.png";
import liveGame7 from "../../images/liveGame7.png";
import TVBetGame1 from "../../images/TVBetGame1.png";
import TVBetGame2 from "../../images/TVBetGame2.png";
import TVBetGame3 from "../../images/TVBetGame3.png";
import TVBetGame4 from "../../images/TVBetGame4.png";
import TVBetGame5 from "../../images/TVBetGame5.png";
import TVBetGame6 from "../../images/TVBetGame6.png";
import TVBetGame7 from "../../images/TVBetGame7.png";

export default function Home() {
  return (
    <div>
      <HomeHeader />
      <div className="mainHome">
        <SideBar />
        <div className="homeCenterDiv">
          <div className="homeSwipeDiv">
            <img src={homeSwipLeftArrow} className="homeSwipArrowImg" />
            <img src={homeSwipe1} className="homeSwipeImg" />
            <img src={homeSwipe2} className="homeSwipeImg" />
            <img src={homeSwipe3} className="homeSwipeImg" />
            <img src={homeSwipRightArrow} className="homeSwipArrowImg2" />
          </div>
          <div className="homeSecondDiv">
            <div className="homeSecondDivInsideDiv1">
              Free Crypto <br /> Wheel
            </div>
            <div className="homeSecondDivInsideDiv">
              Daily Bonus
              <img src={dailyBonus} className="dailyBonusImg" />
            </div>
            <div className="homeSecondDivInsideDiv">
              Rakeback
              <img src={Rakeback} className="dailyBonusImg" />
            </div>
            <div className="homeSecondDivInsideDiv">
              Vip Club
              <img src={vipClub} className="dailyBonusImg" />
            </div>
            <div className="homeSecondDivInsideDiv">
              Free Boxes
              <img src={freeBoxes} className="dailyBonusImg" />
            </div>
            <div className="homeSecondDivInsideDiv">
              Promocodes
              <img src={Promocodes} className="dailyBonusImg" />
            </div>
          </div>
          <div className="homeThirdDiv"></div>

          <div className="homeFourthDiv">
            <div className="homeFourthDivFirstDiv">
              <div className="homeFourTextDiv">
                <img src={sidebar2} className="originalGameImg" />
                Original <span className="homeFourTextDivYellow"> games </span>
              </div>
              <div className="gameaArrowDiv">
                <img src={homeSwipLeftArrow} className="gameArrowImg2" />
                <img src={homeSwipRightArrow} className="gameArrowImg" />
              </div>
            </div>
            <div className="homeFourthDivSecondDiv">
              <img src={game1} className="gameImg" />
              <img src={game2} className="gameImg" />
              <img src={game3} className="gameImg" />
              <img src={game4} className="gameImg" />
              <img src={game5} className="gameImg" />
              <img src={game6} className="gameImg" />
              <img src={game7} className="gameImg" />
            </div>
          </div>
          <div className="homeFourthDiv">
            <div className="homeFourthDivFirstDiv">
              <div className="homeFourTextDiv">
                <img src={sidebar2} className="originalGameImg" />
                Top <span className="homeFourTextDivYellow"> games </span>
              </div>
              <div className="gameaArrowDiv">
                <img src={homeSwipLeftArrow} className="gameArrowImg2" />
                <img src={homeSwipRightArrow} className="gameArrowImg" />
              </div>
            </div>
            <div className="homeFourthDivSecondDiv">
              <img src={game8} className="gameImg" />
              <img src={game9} className="gameImg" />
              <img src={game10} className="gameImg" />
              <img src={game11} className="gameImg" />
              <img src={game12} className="gameImg" />
              <img src={game13} className="gameImg" />
              <img src={game14} className="gameImg" />
            </div>
          </div>
          <div className="paymentDiv">
            <span className="paymentText">
              Need cryptocurrency? Buy using a card.
            </span>
            <img src={paymentImg} className="paymentImg" />
            <button className="paymentBtn">
              Buy <br /> Cryptocurrency
            </button>
          </div>
          <div className="homeFourthDiv">
            <div className="homeFourthDivFirstDiv">
              <div className="homeFourTextDiv">
                <img src={sidebar2} className="originalGameImg" />
                Hit <span className="homeFourTextDivYellow"> games </span>
              </div>
              <div className="gameaArrowDiv">
                <img src={homeSwipLeftArrow} className="gameArrowImg2" />
                <img src={homeSwipRightArrow} className="gameArrowImg" />
              </div>
            </div>
            <div className="homeFourthDivSecondDiv">
              <img src={game15} className="gameImg" />
              <img src={game16} className="gameImg" />
              <img src={game17} className="gameImg" />
              <img src={game18} className="gameImg" />
              <img src={game19} className="gameImg" />
              <img src={game20} className="gameImg" />
              <img src={game21} className="gameImg" />
            </div>
          </div>
          <div className="homeFourthDiv">
            <div className="homeFourthDivFirstDiv">
              <div className="homeFourTextDiv">
                <img src={sidebar2} className="originalGameImg" />
                Hot <span className="homeFourTextDivYellow"> games </span>
              </div>
              <div className="gameaArrowDiv">
                <img src={homeSwipLeftArrow} className="gameArrowImg2" />
                <img src={homeSwipRightArrow} className="gameArrowImg" />
              </div>
            </div>
            <div className="homeFourthDivSecondDiv">
              <img src={game22} className="gameImg" />
              <img src={game23} className="gameImg" />
              <img src={game24} className="gameImg" />
              <img src={game25} className="gameImg" />
              <img src={game26} className="gameImg" />
              <img src={game27} className="gameImg" />
              <img src={game28} className="gameImg" />
            </div>
          </div>
          <div className="homeFourthDiv">
            <div className="homeFourthDivFirstDiv">
              <div className="homeFourTextDiv">
                <img src={sidebar2} className="originalGameImg" />
                Cold <span className="homeFourTextDivYellow"> games </span>
              </div>
              <div className="gameaArrowDiv">
                <img src={homeSwipLeftArrow} className="gameArrowImg2" />
                <img src={homeSwipRightArrow} className="gameArrowImg" />
              </div>
            </div>
            <div className="homeFourthDivSecondDiv">
              <img src={game29} className="gameImg" />
              <img src={game30} className="gameImg" />
              <img src={game31} className="gameImg" />
              <img src={game32} className="gameImg" />
              <img src={game33} className="gameImg" />
              <img src={game34} className="gameImg" />
              <img src={game35} className="gameImg" />
            </div>
          </div>
          <div className="homeFourthDiv">
            <div className="homeFourthDivFirstDiv">
              <div className="homeFourTextDiv">
                <img src={sidebar2} className="originalGameImg" />
                GAME PROVIDERS
                {/* <span className="homeFourTextDivYellow"> games </span> */}
              </div>
              <div className="gameaArrowDiv">
                <img src={homeSwipLeftArrow} className="gameArrowImg2" />
                <img src={homeSwipRightArrow} className="gameArrowImg" />
              </div>
            </div>
            <div className="gameProviderDiv">
              <img src={gameProvider1} className="homeProviderImg" />
              <img src={gameProvider2} className="homeProviderImg" />
              <img src={gameProvider3} className="homeProviderImg" />
              <img src={gameProvider4} className="homeProviderImg" />
              <img src={gameProvider5} className="homeProviderImg" />
              <img src={gameProvider6} className="homeProviderImg" />
              <img src={gameProvider7} className="homeProviderImg" />
            </div>
          </div>
          <div className="homeFourthDiv">
            <div className="homeFourthDivFirstDiv">
              <div className="homeFourTextDiv">
                <img src={sidebar2} className="originalGameImg" />
                RECOMMENDED
                <span className="homeFourTextDivYellow"> LIVE Games </span>
              </div>
              <div className="gameaArrowDiv">
                <img src={homeSwipLeftArrow} className="gameArrowImg2" />
                <img src={homeSwipRightArrow} className="gameArrowImg" />
              </div>
            </div>
            <div className="homeFourthDivSecondDiv">
              <img src={liveGame1} className="gameImg" />
              <img src={liveGame2} className="gameImg" />
              <img src={liveGame3} className="gameImg" />
              <img src={liveGame4} className="gameImg" />
              <img src={liveGame5} className="gameImg" />
              <img src={liveGame6} className="gameImg" />
              <img src={liveGame7} className="gameImg" />
            </div>
          </div>
          <div className="homeFourthDiv">
            <div className="homeFourthDivFirstDiv">
              <div className="homeFourTextDiv">
                <img src={sidebar2} className="originalGameImg" />
                TVBet
                <span className="homeFourTextDivYellow"> Games </span>
              </div>
              <div className="gameaArrowDiv">
                <img src={homeSwipLeftArrow} className="gameArrowImg2" />
                <img src={homeSwipRightArrow} className="gameArrowImg" />
              </div>
            </div>
            <div className="homeFourthDivSecondDiv">
              <img src={TVBetGame1} className="gameImg" />
              <img src={TVBetGame2} className="gameImg" />
              <img src={TVBetGame3} className="gameImg" />
              <img src={TVBetGame4} className="gameImg" />
              <img src={TVBetGame5} className="gameImg" />
              <img src={TVBetGame6} className="gameImg" />
              <img src={TVBetGame7} className="gameImg" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
